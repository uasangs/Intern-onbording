
# """
# Offer Letter & Certificate generator using python-docx template substitution.

# Strategy: Use the real Grasim docx template (with exact logos, header, footer,
# fonts, margins) as the base. Substitute only the dynamic text nodes in the XML,
# leaving all formatting, images, and layout completely untouched.

# This produces a 100% layout-identical output to the original letter.
# """

# import os
# import re
# import copy
# import shutil
# from datetime import datetime
# from zipfile import ZipFile
# from lxml import etree
# from app.core.config import settings

# UPLOAD_DIR = settings.UPLOAD_DIR
# TEMPLATES_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "pdf", "templates")

# # Word XML namespace
# W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"


# def _ensure_dir(path: str):
#     os.makedirs(path, exist_ok=True)


# def _ordinal(n: int) -> str:
#     """Return ordinal string: 1 -> '1st', 2 -> '2nd', etc."""
#     if 10 <= n % 100 <= 20:
#         suffix = "th"
#     else:
#         suffix = {1: "st", 2: "nd", 3: "rd"}.get(n % 10, "th")
#     return f"{n}{suffix}"


# def _format_date_long(d) -> str:
#     """Format date as '20th May 2025'"""
#     if not d:
#         return ""
#     return f"{_ordinal(d.day)} {d.strftime('%B %Y')}"


# def _format_date_letter(d) -> str:
#     """Format date as '19-apr-2026' for the top of the letter"""
#     if not d:
#         return ""
#     return d.strftime("%d-%b-%Y").lower()


# def _get_full_text(paragraph_elem) -> str:
#     """Get concatenated text of all <w:t> elements in a paragraph."""
#     return "".join(
#         t.text or ""
#         for t in paragraph_elem.iter(f"{{{W}}}t")
#     )


# def _set_paragraph_text(paragraph_elem, new_text: str):
#     """
#     Replace all runs in a paragraph with a single run containing new_text,
#     preserving the formatting of the first run found.
#     """
#     ns = f"{{{W}}}"

#     # Find the first run to copy its formatting (rPr)
#     first_run = paragraph_elem.find(f"{ns}r")
#     first_rpr = None
#     if first_run is not None:
#         first_rpr = first_run.find(f"{ns}rPr")

#     # Remove all existing runs (but keep pPr)
#     for r in paragraph_elem.findall(f"{ns}r"):
#         paragraph_elem.remove(r)

#     # Create new run with preserved formatting
#     new_run = etree.SubElement(paragraph_elem, f"{ns}r")
#     if first_rpr is not None:
#         new_run.insert(0, copy.deepcopy(first_rpr))

#     new_t = etree.SubElement(new_run, f"{ns}t")
#     new_t.text = new_text
#     if new_text.startswith(" ") or new_text.endswith(" "):
#         new_t.set("{http://www.w3.org/XML/1998/namespace}space", "preserve")


# def _remove_paragraph(body_elem, paragraph_elem):
#     """Remove a paragraph element from body."""
#     body_elem.remove(paragraph_elem)


# def _insert_paragraph_after(body_elem, ref_elem, new_para_elem):
#     """Insert new_para_elem after ref_elem in body."""
#     idx = list(body_elem).index(ref_elem)
#     body_elem.insert(idx + 1, new_para_elem)


# def _make_text_paragraph(reference_para, text: str) -> etree.Element:
#     """Create a new paragraph element cloned from reference_para with given text."""
#     ns = f"{{{W}}}"
#     new_p = copy.deepcopy(reference_para)
#     # Clear all runs
#     for r in new_p.findall(f"{ns}r"):
#         new_p.remove(r)
#     # Add single run
#     first_run = reference_para.find(f"{ns}r")
#     first_rpr = None
#     if first_run is not None:
#         first_rpr = first_run.find(f"{ns}rPr")
#     new_run = etree.SubElement(new_p, f"{ns}r")
#     if first_rpr is not None:
#         new_run.insert(0, copy.deepcopy(first_rpr))
#     new_t = etree.SubElement(new_run, f"{ns}t")
#     new_t.text = text
#     if text and (text.startswith(" ") or text.endswith(" ")):
#         new_t.set("{http://www.w3.org/XML/1998/namespace}space", "preserve")
#     return new_p


# async def generate_offer_letter_pdf(record) -> str:
#     """
#     Generate offer letter docx using the official Grasim template.
#     Returns the URL path to the generated file.
#     """
#     candidate = record.candidate
#     template_path = os.path.join(TEMPLATES_DIR, "offer_letter_template.docx")

#     if not os.path.exists(template_path):
#         raise FileNotFoundError(f"Offer letter template not found: {template_path}")

#     # Build substitution data
#     full_name = candidate.full_name if candidate else "Candidate"
#     first_name = full_name.split()[0] if full_name else "Candidate"
#     gender = candidate.gender if candidate else "male"
#     salutation = "Mr." if gender == "male" else "Ms."

#     institute = candidate.institute_name or ""
#     city = candidate.city or ""
#     state = candidate.state or ""
#     location = record.location or ""
#     duration_weeks = record.duration_weeks or ""

#     # Dates
#     letter_date = _format_date_letter(record.start_date or datetime.now())
#     start_str = _format_date_long(record.start_date)
#     end_str = _format_date_long(record.end_date)

#     # Stipend
#     has_stipend = record.stipend_amount and float(record.stipend_amount) > 0
#     stipend_str = f"Rs {int(record.stipend_amount):,}/- per month" if has_stipend else ""

#     # HR signatory — use letter_format from masters if configured
#     hr_name = settings.HR_HEAD_NAME
#     hr_title = settings.HR_HEAD_TITLE
#     hr_division = location

#     try:
#         from app.core.database import SessionLocal
#         from app.models.models import MasterData
#         db = SessionLocal()
#         try:
#             row = db.query(MasterData).filter(MasterData.id == 1).first()
#             if row and row.letter_formats:
#                 fmt = next(
#                     (f for f in row.letter_formats if f.get("department") == record.department),
#                     None
#                 )
#                 if fmt:
#                     hr_name = fmt.get("signatory", hr_name).split("\n")[0].strip()
#                     hr_division = fmt.get("department", hr_division)
#         finally:
#             db.close()
#     except Exception:
#         pass

#     # Copy template to working location
#     out_dir = os.path.join(UPLOAD_DIR, "offer_letters")
#     _ensure_dir(out_dir)
#     filename = f"offer_{record.id}.docx"
#     out_path = os.path.join(out_dir, filename)
#     shutil.copy2(template_path, out_path)

#     # Parse and modify document XML inside the docx zip
#     with ZipFile(out_path, "r") as zin:
#         doc_xml = zin.read("word/document.xml")

#     tree = etree.fromstring(doc_xml)
#     body = tree.find(f"{{{W}}}body")
#     paragraphs = body.findall(f"{{{W}}}p")

#     ns = f"{{{W}}}"

#     for para in paragraphs:
#         text = _get_full_text(para)

#         # ── Date line ─────────────────────────────────────────
#         if text.strip() == "Date":
#             _set_paragraph_text(para, letter_date)

#         # ── Salutation + Name (Mr./Ms. Full Name) ─────────────
#         elif text.strip() == "Name":
#             _set_paragraph_text(para, f"{salutation} {full_name}")

#         # ── College/Institute ──────────────────────────────────
#         elif text.strip() == "College Name":
#             _set_paragraph_text(para, institute)

#         # ── City / Location ────────────────────────────────────
#         elif text.strip() == "Location":
#             loc_text = city
#             if state:
#                 loc_text += f"\nDistrict- {state}"
#             _set_paragraph_text(para, loc_text)

#         # ── Dear Name ──────────────────────────────────────────
#         elif text.strip() == "Dear Name,":
#             _set_paragraph_text(para, f"Dear {first_name},")

#         # ── Body paragraph with duration/dates ─────────────────
#         elif "…………… weeks starting from" in text or "weeks starting from" in text:
#             # Rebuild this paragraph with dynamic content
#             new_body_text = (
#                 f"This is in regard to your request letter for internship with "
#                 f"Grasim Industries Ltd. (Grasim). We are pleased to inform you "
#                 f"that you have been accepted as an Intern for a period of "
#                 f"{duration_weeks} weeks starting from {start_str} to {end_str}."
#             )
#             # We need to handle the mixed formatting in this paragraph carefully
#             # Find and replace the full text while preserving runs structure
#             # Simplest: replace all runs with one run using first run's format
#             # The bold/italic on "at LOCATION" will be rebuilt if location exists
#             _set_paragraph_text(para, new_body_text)

#         # ── Stipend bullet ─────────────────────────────────────
#         elif "You will be paid a Stipend" in text:
#             if has_stipend:
#                 # Replace the amount while keeping the sentence structure
#                 # Rebuild with correct amount
#                 _set_paragraph_text(
#                     para,
#                     f"You will be paid a Stipend of {stipend_str}, inclusive of all taxes."
#                 )
#             else:
#                 # No stipend — remove this bullet paragraph entirely
#                 body.remove(para)

#         # ── Signatory name ─────────────────────────────────────
#         elif text.strip() == "Sheba Banerjee":
#             _set_paragraph_text(para, hr_name)

#         # ── Signatory division (MBDD) ──────────────────────────
#         elif text.strip() == "MBDD":
#             _set_paragraph_text(para, hr_division)

#     # Write modified XML back into the docx
#     modified_xml = etree.tostring(tree, xml_declaration=True, encoding="UTF-8", standalone=True)

#     # Repack the docx with modified document.xml
#     import tempfile
#     tmp_path = out_path + ".tmp"
#     with ZipFile(out_path, "r") as zin:
#         with ZipFile(tmp_path, "w") as zout:
#             for item in zin.infolist():
#                 if item.filename == "word/document.xml":
#                     zout.writestr(item, modified_xml)
#                 else:
#                     zout.writestr(item, zin.read(item.filename))

#     os.replace(tmp_path, out_path)
#     return f"/uploads/offer_letters/{filename}"


# async def generate_certificate_pdf(record, payload) -> str:
#     """
#     Generate experience certificate using the official Grasim certificate template.
#     Uses docx template substitution — preserves exact logo, layout, fonts, footer.
#     Returns the URL path to the generated .docx file.
#     """
#     candidate = record.candidate
#     template_path = os.path.join(TEMPLATES_DIR, "certificate_template.docx")

#     if not os.path.exists(template_path):
#         raise FileNotFoundError(f"Certificate template not found: {template_path}")

#     # Build all dynamic values
#     full_name  = candidate.full_name if candidate else "Candidate"
#     gender     = candidate.gender if candidate else "male"
#     salutation = "Mr." if gender == "male" else "Ms."
#     pronoun    = "his" if gender == "male" else "her"  # "during his/her tenure"

#     institute  = candidate.institute_name or ""
#     location   = record.location or ""
#     weeks      = record.duration_weeks or ""
#     conduct    = payload.conduct_remark.lower()  # "good", "excellent", etc.
#     project    = payload.project_title
#     guides     = payload.guide_names

#     # Dates — ordinal format: "20th May 2025"
#     start_str = _format_date_long(record.start_date)
#     end_str   = _format_date_long(record.end_date)

#     # Issue date — "July 28, 2025" format (matches original)
#     issue_date = payload.issue_date
#     issue_str  = issue_date.strftime("%B") + " " + str(issue_date.day) + ", " + str(issue_date.year)

#     # HR signatory
#     hr_name     = settings.HR_HEAD_NAME
#     hr_division = location
#     try:
#         from app.core.database import SessionLocal
#         from app.models.models import MasterData
#         db = SessionLocal()
#         try:
#             row = db.query(MasterData).filter(MasterData.id == 1).first()
#             if row and row.letter_formats:
#                 fmt = next(
#                     (f for f in row.letter_formats if f.get("department") == record.department),
#                     None
#                 )
#                 if fmt:
#                     hr_name     = fmt.get("signatory", hr_name).split("\n")[0].strip()
#                     hr_division = fmt.get("department", hr_division)
#         finally:
#             db.close()
#     except Exception:
#         pass

#     # Copy template
#     out_dir  = os.path.join(UPLOAD_DIR, "certificates")
#     _ensure_dir(out_dir)
#     filename = f"cert_{record.id}.docx"
#     out_path = os.path.join(out_dir, filename)
#     shutil.copy2(template_path, out_path)

#     # Parse document XML
#     with ZipFile(out_path, "r") as zin:
#         doc_xml = zin.read("word/document.xml")

#     tree = etree.fromstring(doc_xml)
#     body = tree.find(f"{{{W}}}body")
#     paragraphs = body.findall(f"{{{W}}}p")

#     for para in paragraphs:
#         text = _get_full_text(para)

#         # ── Issue date (top of letter) ─────────────────────────
#         if text.strip() in ("July 28, 2025", "July 28,2025") or (
#             "2025" in text and len(text.strip()) < 20 and
#             any(m in text for m in ["January","February","March","April","May","June",
#                                      "July","August","September","October","November","December"])
#         ):
#             _set_paragraph_text(para, issue_str)

#         # ── Main certify paragraph ─────────────────────────────
#         elif "This is to certify that" in text:
#             # Build: "This is to certify that Mr. Niket Totala, a student of VJTI, Mumbai
#             #          has successfully completed his Internship at TRADC
#             #          (Grasim Industries Limited), for the period of 8 weeks
#             #          starting from 20th May 2025 to 18th July 2025."
#             new_text = (
#                 f"This is to certify that {salutation} {full_name}, "
#                 f"a student of {institute} has successfully completed "
#                 f"{pronoun} Internship at {location} (Grasim Industries Limited), "
#                 f"for the period of {weeks} weeks starting from "
#                 f"{start_str} to {end_str}."
#             )
#             _set_paragraph_text(para, new_text)

#         # ── Conduct paragraph ──────────────────────────────────
#         elif "During" in text and "tenure" in text and "conduct" in text:
#             new_text = (
#                 f"During {pronoun} tenure with us as Intern "
#                 f"{pronoun} conduct was {conduct}."
#             )
#             _set_paragraph_text(para, new_text)

#         # ── Project & guide paragraph ──────────────────────────
#         elif "The project undertaken was" in text or "project undertaken" in text:
#             new_text = (
#                 f'The project undertaken was “{project}” '
#                 f"under the guidance of {guides}."
#             )
#             _set_paragraph_text(para, new_text)

#         # ── Closing wish paragraph ─────────────────────────────
#         elif "We wish" in text and "future endeavor" in text:
#             new_text = (
#                 f"We wish {pronoun} all the best in {pronoun} future endeavor. "
#                 f"For Grasim Industries Ltd."
#             )
#             _set_paragraph_text(para, new_text)

#         # ── Signatory name ─────────────────────────────────────
#         elif text.strip() == "Sheba Banerjee":
#             _set_paragraph_text(para, hr_name)

#         # ── Signatory title + division ─────────────────────────
#         elif "Head" in text and "Human Resources" in text:
#             _set_paragraph_text(para, f"Head – Human Resources {hr_division}")

#     # Write back
#     modified_xml = etree.tostring(
#         tree, xml_declaration=True, encoding="UTF-8", standalone=True
#     )

#     import tempfile
#     tmp_path = out_path + ".tmp"
#     with ZipFile(out_path, "r") as zin:
#         with ZipFile(tmp_path, "w") as zout:
#             for item in zin.infolist():
#                 if item.filename == "word/document.xml":
#                     zout.writestr(item, modified_xml)
#                 else:
#                     zout.writestr(item, zin.read(item.filename))

#     os.replace(tmp_path, out_path)
#     return f"/uploads/certificates/{filename}"



"""
Offer Letter & Certificate generator using python-docx template substitution.

Strategy: Use the real Grasim docx template (with exact logos, header, footer,
fonts, margins) as the base. Substitute only the dynamic text nodes in the XML,
leaving all formatting, images, and layout completely untouched.

This produces a 100% layout-identical output to the original letter.
"""

import os
import re
import copy
import shutil
from datetime import datetime
from zipfile import ZipFile
from lxml import etree
from app.core.config import settings

UPLOAD_DIR = settings.UPLOAD_DIR


def _convert_docx_to_pdf(docx_path: str, out_dir: str):
    """
    Convert .docx to .pdf. Tries multiple methods in order:
    1. docx2pdf (uses MS Word on Windows, LibreOffice on Linux/Mac)
    2. LibreOffice CLI (Linux/Mac fallback)
    3. soffice CLI (Windows LibreOffice fallback)
    Returns pdf path or None if all methods fail.
    """
    import subprocess
    pdf_path = os.path.join(out_dir, os.path.basename(docx_path).replace(".docx", ".pdf"))

    # Method 1: docx2pdf — uses MS Word on Windows, LibreOffice on Linux/Mac
    try:
        from docx2pdf import convert
        convert(docx_path, pdf_path)
        if os.path.exists(pdf_path):
            return pdf_path
    except Exception:
        pass

    # Method 2: LibreOffice CLI (Linux/Mac)
    for cmd in ["libreoffice", "soffice"]:
        try:
            result = subprocess.run(
                [cmd, "--headless", "--convert-to", "pdf", "--outdir", out_dir, docx_path],
                capture_output=True, text=True, timeout=60
            )
            if result.returncode == 0 and os.path.exists(pdf_path):
                return pdf_path
        except (subprocess.TimeoutExpired, FileNotFoundError):
            continue

    return None

TEMPLATES_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "pdf", "templates")

# Word XML namespace
W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"


def _ensure_dir(path: str):
    os.makedirs(path, exist_ok=True)


def _ordinal(n: int) -> str:
    """Return ordinal string: 1 -> '1st', 2 -> '2nd', etc."""
    if 10 <= n % 100 <= 20:
        suffix = "th"
    else:
        suffix = {1: "st", 2: "nd", 3: "rd"}.get(n % 10, "th")
    return f"{n}{suffix}"


def _format_date_long(d) -> str:
    """Format date as '20th May 2025'"""
    if not d:
        return ""
    return f"{_ordinal(d.day)} {d.strftime('%B %Y')}"


def _format_date_letter(d) -> str:
    """Format date as '19-apr-2026' for the top of the letter"""
    if not d:
        return ""
    return d.strftime("%d-%b-%Y").lower()


def _get_full_text(paragraph_elem) -> str:
    """Get concatenated text of all <w:t> elements in a paragraph."""
    return "".join(
        t.text or ""
        for t in paragraph_elem.iter(f"{{{W}}}t")
    )


def _set_paragraph_text(paragraph_elem, new_text: str):
    """
    Replace all runs in a paragraph with a single run containing new_text,
    preserving the formatting of the first run found.
    """
    ns = f"{{{W}}}"

    # Find the first run to copy its formatting (rPr)
    first_run = paragraph_elem.find(f"{ns}r")
    first_rpr = None
    if first_run is not None:
        first_rpr = first_run.find(f"{ns}rPr")

    # Remove all existing runs (but keep pPr)
    for r in paragraph_elem.findall(f"{ns}r"):
        paragraph_elem.remove(r)

    # Create new run with preserved formatting
    new_run = etree.SubElement(paragraph_elem, f"{ns}r")
    if first_rpr is not None:
        new_run.insert(0, copy.deepcopy(first_rpr))

    new_t = etree.SubElement(new_run, f"{ns}t")
    new_t.text = new_text
    if new_text.startswith(" ") or new_text.endswith(" "):
        new_t.set("{http://www.w3.org/XML/1998/namespace}space", "preserve")


def _remove_paragraph(body_elem, paragraph_elem):
    """Remove a paragraph element from body."""
    body_elem.remove(paragraph_elem)


def _insert_paragraph_after(body_elem, ref_elem, new_para_elem):
    """Insert new_para_elem after ref_elem in body."""
    idx = list(body_elem).index(ref_elem)
    body_elem.insert(idx + 1, new_para_elem)


def _make_text_paragraph(reference_para, text: str) -> etree.Element:
    """Create a new paragraph element cloned from reference_para with given text."""
    ns = f"{{{W}}}"
    new_p = copy.deepcopy(reference_para)
    # Clear all runs
    for r in new_p.findall(f"{ns}r"):
        new_p.remove(r)
    # Add single run
    first_run = reference_para.find(f"{ns}r")
    first_rpr = None
    if first_run is not None:
        first_rpr = first_run.find(f"{ns}rPr")
    new_run = etree.SubElement(new_p, f"{ns}r")
    if first_rpr is not None:
        new_run.insert(0, copy.deepcopy(first_rpr))
    new_t = etree.SubElement(new_run, f"{ns}t")
    new_t.text = text
    if text and (text.startswith(" ") or text.endswith(" ")):
        new_t.set("{http://www.w3.org/XML/1998/namespace}space", "preserve")
    return new_p


async def generate_offer_letter_pdf(record) -> str:
    """
    Generate offer letter docx using the official Grasim template.
    Returns the URL path to the generated file.
    """
    candidate = record.candidate
    template_path = os.path.join(TEMPLATES_DIR, "offer_letter_template.docx")

    if not os.path.exists(template_path):
        raise FileNotFoundError(f"Offer letter template not found: {template_path}")

    # Build substitution data
    full_name = candidate.full_name if candidate else "Candidate"
    first_name = full_name.split()[0] if full_name else "Candidate"
    gender = candidate.gender if candidate else "male"
    salutation = "Mr." if gender == "male" else "Ms."

    institute = candidate.institute_name or ""
    city = candidate.city or ""
    state = candidate.state or ""
    location = record.location or ""
    duration_weeks = record.duration_weeks or ""

    # Dates
    letter_date = _format_date_letter(record.start_date or datetime.now())
    start_str = _format_date_long(record.start_date)
    end_str = _format_date_long(record.end_date)

    # Stipend
    has_stipend = record.stipend_amount and float(record.stipend_amount) > 0
    stipend_str = f"Rs {int(record.stipend_amount):,}/- per month" if has_stipend else ""

    # HR signatory — use letter_format from masters if configured
    hr_name = settings.HR_HEAD_NAME
    hr_title = settings.HR_HEAD_TITLE
    hr_division = location

    try:
        from app.core.database import SessionLocal
        from app.models.models import MasterData
        db = SessionLocal()
        try:
            row = db.query(MasterData).filter(MasterData.id == 1).first()
            if row and row.letter_formats:
                fmt = next(
                    (f for f in row.letter_formats if f.get("department") == record.department),
                    None
                )
                if fmt:
                    hr_name = fmt.get("signatory", hr_name).split("\n")[0].strip()
                    hr_division = fmt.get("department", hr_division)
        finally:
            db.close()
    except Exception:
        pass

    # Copy template to working location
    out_dir = os.path.join(UPLOAD_DIR, "offer_letters")
    _ensure_dir(out_dir)
    filename = f"offer_{record.id}.docx"
    out_path = os.path.join(out_dir, filename)
    shutil.copy2(template_path, out_path)

    # Parse and modify document XML inside the docx zip
    with ZipFile(out_path, "r") as zin:
        doc_xml = zin.read("word/document.xml")

    tree = etree.fromstring(doc_xml)
    body = tree.find(f"{{{W}}}body")
    paragraphs = body.findall(f"{{{W}}}p")

    ns = f"{{{W}}}"

    for para in paragraphs:
        text = _get_full_text(para)

        # ── Date line ─────────────────────────────────────────
        if text.strip() == "Date":
            _set_paragraph_text(para, letter_date)

        # ── Salutation + Name (Mr./Ms. Full Name) ─────────────
        elif text.strip() == "Name":
            _set_paragraph_text(para, f"{salutation} {full_name}")

        # ── College/Institute ──────────────────────────────────
        elif text.strip() == "College Name":
            _set_paragraph_text(para, institute)

        # ── City / Location ────────────────────────────────────
        elif text.strip() == "Location":
            loc_text = city
            if state:
                loc_text += f"\nDistrict- {state}"
            _set_paragraph_text(para, loc_text)

        # ── Dear Name ──────────────────────────────────────────
        elif text.strip() == "Dear Name,":
            _set_paragraph_text(para, f"Dear {first_name},")

        # ── Body paragraph with duration/dates ─────────────────
        elif "…………… weeks starting from" in text or "weeks starting from" in text:
            # Rebuild this paragraph with dynamic content
            new_body_text = (
                f"This is in regard to your request letter for internship with "
                f"Grasim Industries Ltd. (Grasim). We are pleased to inform you "
                f"that you have been accepted as an Intern for a period of "
                f"{duration_weeks} weeks starting from {start_str} to {end_str}."
            )
            # We need to handle the mixed formatting in this paragraph carefully
            # Find and replace the full text while preserving runs structure
            # Simplest: replace all runs with one run using first run's format
            # The bold/italic on "at LOCATION" will be rebuilt if location exists
            _set_paragraph_text(para, new_body_text)

        # ── Stipend bullet ─────────────────────────────────────
        elif "You will be paid a Stipend" in text:
            if has_stipend:
                # Replace the amount while keeping the sentence structure
                # Rebuild with correct amount
                _set_paragraph_text(
                    para,
                    f"You will be paid a Stipend of {stipend_str}, inclusive of all taxes."
                )
            else:
                # No stipend — remove this bullet paragraph entirely
                body.remove(para)

        # ── Signatory name ─────────────────────────────────────
        elif text.strip() == "Sheba Banerjee":
            _set_paragraph_text(para, hr_name)

        # ── Signatory division (MBDD) ──────────────────────────
        elif text.strip() == "MBDD":
            _set_paragraph_text(para, hr_division)

    # Write modified XML back into the docx
    modified_xml = etree.tostring(tree, xml_declaration=True, encoding="UTF-8", standalone=True)

    # Repack the docx with modified document.xml
    import tempfile
    tmp_path = out_path + ".tmp"
    with ZipFile(out_path, "r") as zin:
        with ZipFile(tmp_path, "w") as zout:
            for item in zin.infolist():
                if item.filename == "word/document.xml":
                    zout.writestr(item, modified_xml)
                else:
                    zout.writestr(item, zin.read(item.filename))

    os.replace(tmp_path, out_path)
    pdf_path = _convert_docx_to_pdf(out_path, out_dir)
    if pdf_path:
        return f"/uploads/offer_letters/{os.path.basename(pdf_path)}"
    return f"/uploads/offer_letters/{filename}"


async def generate_certificate_pdf(record, payload) -> str:
    """
    Generate experience certificate using the official Grasim certificate template.
    Uses docx template substitution — preserves exact logo, layout, fonts, footer.
    Returns the URL path to the generated .docx file.
    """
    candidate = record.candidate
    template_path = os.path.join(TEMPLATES_DIR, "certificate_template.docx")

    if not os.path.exists(template_path):
        raise FileNotFoundError(f"Certificate template not found: {template_path}")

    # Build all dynamic values
    full_name  = candidate.full_name if candidate else "Candidate"
    gender     = candidate.gender if candidate else "male"
    salutation = "Mr." if gender == "male" else "Ms."
    pronoun    = "his" if gender == "male" else "her"  # "during his/her tenure"

    institute  = candidate.institute_name or ""
    location   = record.location or ""
    weeks      = record.duration_weeks or ""
    conduct    = payload.conduct_remark.lower()  # "good", "excellent", etc.
    project    = payload.project_title
    guides     = payload.guide_names

    # Dates — ordinal format: "20th May 2025"
    start_str = _format_date_long(record.start_date)
    end_str   = _format_date_long(record.end_date)

    # Issue date — "July 28, 2025" format (matches original)
    issue_date = payload.issue_date
    issue_str  = issue_date.strftime("%B") + " " + str(issue_date.day) + ", " + str(issue_date.year)

    # HR signatory
    hr_name     = settings.HR_HEAD_NAME
    hr_division = location
    try:
        from app.core.database import SessionLocal
        from app.models.models import MasterData
        db = SessionLocal()
        try:
            row = db.query(MasterData).filter(MasterData.id == 1).first()
            if row and row.letter_formats:
                fmt = next(
                    (f for f in row.letter_formats if f.get("department") == record.department),
                    None
                )
                if fmt:
                    hr_name     = fmt.get("signatory", hr_name).split("\n")[0].strip()
                    hr_division = fmt.get("department", hr_division)
        finally:
            db.close()
    except Exception:
        pass

    # Copy template
    out_dir  = os.path.join(UPLOAD_DIR, "certificates")
    _ensure_dir(out_dir)
    filename = f"cert_{record.id}.docx"
    out_path = os.path.join(out_dir, filename)
    shutil.copy2(template_path, out_path)

    # Parse document XML
    with ZipFile(out_path, "r") as zin:
        doc_xml = zin.read("word/document.xml")

    tree = etree.fromstring(doc_xml)
    body = tree.find(f"{{{W}}}body")
    paragraphs = body.findall(f"{{{W}}}p")

    for para in paragraphs:
        text = _get_full_text(para)

        # ── Issue date (top of letter) ─────────────────────────
        if text.strip() in ("July 28, 2025", "July 28,2025") or (
            "2025" in text and len(text.strip()) < 20 and
            any(m in text for m in ["January","February","March","April","May","June",
                                     "July","August","September","October","November","December"])
        ):
            _set_paragraph_text(para, issue_str)

        # ── Main certify paragraph ─────────────────────────────
        elif "This is to certify that" in text:
            # Build: "This is to certify that Mr. Niket Totala, a student of VJTI, Mumbai
            #          has successfully completed his Internship at TRADC
            #          (Grasim Industries Limited), for the period of 8 weeks
            #          starting from 20th May 2025 to 18th July 2025."
            new_text = (
                f"This is to certify that {salutation} {full_name}, "
                f"a student of {institute} has successfully completed "
                f"{pronoun} Internship at {location} (Grasim Industries Limited), "
                f"for the period of {weeks} weeks starting from "
                f"{start_str} to {end_str}."
            )
            _set_paragraph_text(para, new_text)

        # ── Conduct paragraph ──────────────────────────────────
        elif "During" in text and "tenure" in text and "conduct" in text:
            new_text = (
                f"During {pronoun} tenure with us as Intern "
                f"{pronoun} conduct was {conduct}."
            )
            _set_paragraph_text(para, new_text)

        # ── Project & guide paragraph ──────────────────────────
        elif "The project undertaken was" in text or "project undertaken" in text:
            new_text = (
                f'The project undertaken was “{project}” '
                f"under the guidance of {guides}."
            )
            _set_paragraph_text(para, new_text)

        # ── Closing wish paragraph ─────────────────────────────
        elif "We wish" in text and "future endeavor" in text:
            new_text = (
                f"We wish {pronoun} all the best in {pronoun} future endeavor. "
                f"For Grasim Industries Ltd."
            )
            _set_paragraph_text(para, new_text)

        # ── Signatory name ─────────────────────────────────────
        elif text.strip() == "Sheba Banerjee":
            _set_paragraph_text(para, hr_name)

        # ── Signatory title + division ─────────────────────────
        elif "Head" in text and "Human Resources" in text:
            _set_paragraph_text(para, f"Head – Human Resources {hr_division}")

    # Write back
    modified_xml = etree.tostring(
        tree, xml_declaration=True, encoding="UTF-8", standalone=True
    )

    import tempfile
    tmp_path = out_path + ".tmp"
    with ZipFile(out_path, "r") as zin:
        with ZipFile(tmp_path, "w") as zout:
            for item in zin.infolist():
                if item.filename == "word/document.xml":
                    zout.writestr(item, modified_xml)
                else:
                    zout.writestr(item, zin.read(item.filename))

    os.replace(tmp_path, out_path)
    pdf_path = _convert_docx_to_pdf(out_path, out_dir)
    if pdf_path:
        return f"/uploads/certificates/{os.path.basename(pdf_path)}"
    return f"/uploads/certificates/{filename}"